package com.example.test2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity11 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main11);
    }
}